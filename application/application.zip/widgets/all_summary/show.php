<div id="<?php echo $widget_name ?>_<?php echo $uniqid ?>"> 
	<h1 class="text-center bold"><?php echo $count_simcard ?></h1>
	<h4 class="text-center"><i class="fa fa-credit-card"></i> Simcard</h4>
	<h1 class="text-center bold"><?php echo $count_email ?></h1>
	<h4 class="text-center"><i class="fa fa-envelope"></i> Email</h4>
	<h1 class="text-center bold"><?php echo $count_facebook ?></h1>
	<h4 class="text-center"><i class="fa fa-facebook"></i> Facebook</h4>
	<h1 class="text-center bold"><?php echo $count_twitter ?></h1>
	<h4 class="text-center"><i class="fa fa-twitter"></i> Twitter</h4>
	<h1 class="text-center bold"><?php echo $count_email ?></h1>
	<h4 class="text-center"><i class="fa fa-instagram"></i> Instagram</h4>
</div>