<?php

class M_email extends CI_Model{
  
   public function get_phone_number($params){
      $this->db->select('a.phone_number, b.name as provider_name');
      $this->db->join('provider as b', 'a.provider_id = b.id');
      $this->db->where('a.registered', 0);
      $this->db->where('a.status', 1);
      if($params['with_choosed']){
         $this->db->or_where('a.phone_number', $params['with_choosed']);
      }
      return $this->db->get('simcard as a')->result_array();
   }

	public function get_data_email($mode,$params){
		$this->db->select('a.*, b.username as username_pembuat, c.status as status_phone');
      $this->db->join('users as b', 'a.user_id = b.id', 'left');
      $this->db->join('simcard as c', 'a.phone_number = c.phone_number', 'left');

      if($params['search_name'] != ""){
         $this->db->group_start();
         $this->db->like('a.phone_number', $params['search_name']);
         $this->db->or_like('a.password', $params['search_name']);
         $this->db->or_like('a.email', $params['search_name']);
         $this->db->or_like('b.username', $params['search_name']);
         $this->db->group_end();
      }

      if($params['search_status']!=""){
         $this->db->where('a.status', $params['search_status']);
      }

		$this->db->order_by('a.id','ASC');
		switch ($mode) {
			case 'get':
				return $this->db->get('email as a', 10, $params['offset'])->result_array();
			case 'count':
				return $this->db->get('email as a')->num_rows();
		}
	}

	public function input_data($params){
      $obj = array(
         'phone_number' => $params['phone_number'],
         'email' => $params['emails'],
         'password' => $params['pass'],
         'created_date' => $params['created_date'],
         'birth_day' => $params['birth_day'],
         'status' => $params['status'],
         'info' => $params['status'] == 2 ? 'Blocked' : NULL,
         'user_id' => $params['user_id'],
            
      );
      $hasil = $this->db->insert('email', $obj);
      if($hasil){
         if($params['status'] != 0){
            $obj_phone_number = array(
               'registered' => 1
            );
            $rs_registered = $this->db->update('simcard', $obj_phone_number, array('phone_number' => $params['phone_number']));
            return $rs_registered ? TRUE : FALSE;
         }else{
            return $hasil;
         }
      }else{
     	   return FALSE;
      }

   }

   public function update_data($params){
      $obj = array(
         'phone_number' => $params['phone_number'],
         'email' => $params['email'],
         'password' => $params['password'],
         'birth_day' => $params['birth_day'],
         'status' => $params['status'],
         'user_id' => $params['user_id'],
         'info' => $params['status'] == 2 ? 'Blocked' : NULL
      );

      $where = array(
         'id' => $params['id_email']
      );

      $hasil = $this->db->update('email', $obj, $where);

      if($hasil){
         $this->db->update('simcard', array('registered' => 0), array('phone_number' => $params['phone_number_before']));  
         if($params['status'] != 0){
            $this->db->update('simcard', array('registered' => 1), array('phone_number' => $params['phone_number']));   
         }
         return $hasil; 
      }else{
     	   return false;
      }
    }

	public function delete_data($params){

      $where = array(
         'id' => $params['no']
      );

      $this->db->update('simcard', array('registered' => 0), array('phone_number' => $params['phone_number']));
      $hasil = $this->db->delete('email', $where);

      if($hasil){
     	   return $hasil;
      }else{
     	   return false;
      }
   }
}
?>