<?php

class M_summary extends CI_Model{

	public function all_count($table, $sdate, $edate){
		if($sdate && $edate){
			$this->db->where('date(created_date) BETWEEN "'.$sdate.'" AND "'.$edate.'"');
		}
		return $this->db->count_all_results($table);
	}
}