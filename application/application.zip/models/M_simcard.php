<?php

class M_simcard extends CI_Model{

	public function get_data_simcard($mode,$params){
		$this->db->select('a.*, c.no as no_rak, c.nama_rak, b.name as provider_name, u.first_name');
		$this->db->join('users as u','u.id = a.user_id', 'left');
      $this->db->join('rak as c', 'c.id = a.rak_id', 'left');
      $this->db->join('provider as b', 'b.id = a.provider_id', 'left');

      if($params['search_keyword'] != ""){
         $this->db->group_start();
         $this->db->like('a.phone_number', $params['search_keyword']);
         $this->db->or_like('a.nik', $params['search_keyword']);
         $this->db->or_like('a.nkk', $params['search_keyword']);
         $this->db->or_like('a.saldo', $params['search_keyword']);
         $this->db->or_like('u.first_name', $params['search_keyword']);
         $this->db->group_end();
      }

      if($params['search_provider'] !=""){
         $this->db->where('b.id', $params['search_provider']);
      }

      if($params['search_rak'] != ""){
         $this->db->where('c.id', $params['search_rak']);
      }

      if($params['search_status'] != ""){
         $this->db->where('a.status', $params['search_status']);
      }

		$this->db->order_by('a.created_date', 'desc');
		switch ($mode) {
			case 'get':
				return $this->db->get('simcard as a', 10, $params['offset'])->result_array();
			case 'count':
				return $this->db->get('simcard as a')->num_rows();
		}
	}

	public function get_provider($provider_id){
		$this->db->select('b.name');
		$this->db->join('provider as b','b.id=a.provider_id');
		$this->db->where('b.id',$provider_id);
		return $this->db->get('simcard as a')->result_array();
	}

	public function get_rak($rak_id){
		$this->db->select('b.nama_rak,b.no');
		$this->db->join('rak as b','b.id=a.rak_id');
		$this->db->where('b.id',$rak_id);
		return $this->db->get('simcard as a')->result_array();
	}

   public function input_data($params){
    	$obj = array(
         'phone_number' => $params['no_handphone'],
         'provider_id' => $params['provider'],
         'expired_date' => $params['masa_aktif'],
         'nik' => $params['nik'],
         'nkk' => $params['nkk'],
         'saldo' => $params['saldo'],
         'status' => $params['status'],
         'user_id' => $params['user_id'],
         'rak_id' => $params['rak'],
      );
      return $this->db->insert('simcard', $obj);

   }

   public function update_data($params){
      $obj = array(
         'phone_number' => $params['no_handphone'],
         'provider_id' => $params['provider'],
         'expired_date' => $params['masa_aktif'],
         'nik' => $params['nik'],
         'nkk' => $params['nkk'],
         'saldo' => $params['saldo'],
         'status' => $params['status'],
         'user_id' => $params['user_id'],
         'rak_id' => $params['rak'],
      );
      return $this->db->update('simcard', $obj, array('phone_number' => $params['no_handphone_before']));
   }

    public function delete_data($nope){
        $hasil=$this->db->query("DELETE FROM simcard WHERE phone_number='$nope'");
        if($hasil){
        	return $hasil;
        }else{
        	return false;
        }
    }

}
?>