<?php
if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Migration extends MY_Controller {
   public function __construct() {
      parent::__construct();
      $this->load->library('PHPExcel');
      $this->load->library('excel_reader');
      if (!$this->ion_auth->logged_in() && php_sapi_name() != 'cli') {
         redirect('security?_redirect=' . urlencode(uri_string()));
      }
   }

   public function index() {
      $obj = array(
         'result_view' => 'superadmin/migration',
      );
      $this->rendering_page($obj);
   }

   

   public function migration_master_rak(){
      $excel_reader = $this->excel_reader->read(NULL, './migration/', 'master_rak.xlsx');
      if ($excel_reader['status']) {
         $objPHPExcel = $excel_reader['result'];
         $count = 0;
         $i = 0;
         $row = 1;
         $data = array();
         $objPHPExcel->setActiveSheetIndex(1);   
         $worksheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
         foreach ($worksheet as $value) {
            if ($row != 1) {
               $data[$i]['no'] = isset($value['A']) ? $value['A'] : NULL;
               $data[$i]['nama_rak'] = isset($value['B']) ? $value['B'] : NULL;
            }
            $row++;
            $i++;
         }
         if($data){
            foreach ($data as $v) {
               if($v['no']){
                   $tmp = array(
                     'no' => $v['no'],
                     'nama_rak' => $v['nama_rak']
                  );
                  $insert = $this->on_duplicate('rak', array_filter($tmp));
                  $insert ? $count++ : FALSE;
               }
            }
            echo $count.' Data Updated';
         }
      }else{
         echo json_encode($excel_reader);
      }
   }

   public function format_download() {
      $params = $this->input->get();
      switch ($params['mode']) {
         case 'rak':
            $this->load->view('migration_format/master_rak');
            break;
      }
   }

}