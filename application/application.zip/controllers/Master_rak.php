<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Master_rak extends MY_Controller
{
	
   public function __construct() {
      parent::__construct();
      $this->load->model('Rak');
      $this->load->library('validation_rak');
      if (!$this->ion_auth->logged_in() && php_sapi_name() != 'cli') {
         redirect('security?_redirect=' . urlencode(uri_string()));
      }
   }

   public function index() {
      $obj = array(
         '_css' => array(
            'assets/plugins/simplepagination/simplePagination.css'
         ),
         '_js' => array(
            'assets/plugins/simplepagination/jquery.simplePagination.js"',
         ),
         'result_view' => 'superadmin/rak',
      );
      $this->rendering_page($obj);
   }

   public function get_rak(){
      $param = $this->input->get();
      $list = array();

      $data = $this->Rak->get_data_rak('get',$param);
      if($data){
         foreach ($data as $value) {
            $list[] = array(
               'id_rak' => $value['id'],
               'no_rak' => $value['no'],
               'nama_raks' => $value['nama_rak']
            );
         }
         $response['data'] = $list;
         $response['total'] = $this->Rak->get_data_rak('count',$param);
      }else{
         $response['total']=0;
      }

      echo json_encode($response);
   }

   public function input_rak(){
      
      $params = $this->input->post();
      $response['success'] = FALSE;
      

      if($this->validation_rak->create($params)){

         $data = $this->Rak->input_data($params);

         if($data!=FALSE){
             $response['success'] = TRUE;
             $response['msg'] = 'Data Updated';
         }else{
             $response['msg'] = 'Function Failed';
         }

      }else{
         $response['msg'] = validation_errors();
      }


      $this->json_result($response);

   }

   public function edit_rak(){

      $params = $this->input->post();
      $response['success'] = FALSE;

      if($this->validation_rak->modify($params)){
         $data = $this->Rak->update_data($params);

         if($data!=false){
            $response['success'] = TRUE;
            $response['msg'] = 'Data Updated';
         }else{
            $response['msg'] = 'Function Failed';
         }
      }else{
         $response['msg'] = validation_errors();
      }


      $this->json_result($response);
   }

   public function ambil_edit(){
      $id = $this->input->get('id');
      $data['detail_rak'] = $this->db->where('id', $id)->get('rak')->row_array();
      echo json_encode($data);
   }

   public function hapus(){
      $id = $this->input->get('ids');
      $response['success'] = FALSE;

      $data=$this->Rak->delete_data($id);

      if($data!=false){
         $response['success'] = TRUE;
         $response['msg'] = 'Data Updated';
      }else{
         $response['msg'] = 'Function Failed';
      }
      
      echo json_encode($response);

   }

}
?>