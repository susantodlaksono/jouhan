<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class Master_provider extends MY_Controller{

  public function __construct() {
    	parent::__construct();
        $this->load->model('Provider');
        $this->load->library('Validation_provider');
        if (!$this->ion_auth->logged_in() && php_sapi_name() != 'cli') {
           redirect('security?_redirect=' . urlencode(uri_string()));
      }
  }

  public function index() {
      $obj = array(
       '_css' => array(
          'assets/plugins/simplepagination/simplePagination.css'
       ),
       '_js' => array(
          'assets/plugins/simplepagination/jquery.simplePagination.js"',
       ),
       'result_view' => 'superadmin/provider',
      );
      $this->rendering_page($obj);
    }

   public function render_data(){
      $params = $this->input->get();
      $list = array();

      $rs = $this->Provider->get_provider('get', $params);
      if ($rs) {
          foreach ($rs as $v) {
            $list[] = array(
               'id_provider' => $v['id'],
               'provider_name' => $v['name'],
               'desc' => $v['description']
            );
          }
        $response['response'] = $list;
        $response['total'] = $this->Provider->get_provider('count', $params);
      }else{
         $response['total'] = 0;
      }
      echo json_encode($response);
  }

  public function add(){
      $params = $this->input->post();
      $response['success'] = FALSE;

      if($this->validation_provider->create_provider($params)){ 
          $hasil=$this->Provider->addProvider($params['provname'],$params['desc']);
          if($hasil){
            $response['success'] = TRUE;
            $response['msg'] = 'Data Update';
          }else{
            $response['msg'] = 'Function Failed';
          }
      }else{
         $response['msg'] = validation_errors();
      }
      $this->json_result($response);
  }

  public function update(){
      $params = $this->input->post();
      $response['success'] = FALSE;

      if($this->validation_provider->change_provider($params)){ 
          $hasil=$this->Provider->update($params['ids'],$params['provider'],$params['descript']);
          if($hasil){
            $response['success'] = TRUE;
            $response['msg'] = 'Data Update';
          }else{
            $response['msg'] = 'Function Failed';
          }
      }else{
         $response['msg'] = validation_errors();
      }
      $this->json_result($response);
  }

  public function remove(){
      $kode = $this->input->get('rmv');
      $hasil=$this->Provider->remove($kode);
      if($hasil){
        $response['success'] = TRUE;
        $response['msg'] = 'Data Update';
      }else{
        $response['msg'] = 'Function Failed';
      }
      echo json_encode($response);
  }

  public function getID(){
      $id=$this->input->get('update');
      $data['list']=$this->db->where('id',$id)->get('provider')->row_array();
      echo json_encode($data);
  }
}

?>