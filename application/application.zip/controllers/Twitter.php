<?php

if (!defined('BASEPATH'))
   exit('No direct script access allowed');

class twitter extends MY_Controller
{
	
	public function __construct() {
      parent::__construct();
      $this->load->model('m_twitter');
      $this->load->library('validation_twitter');
      if (!$this->ion_auth->logged_in() && php_sapi_name() != 'cli') {
         redirect('security');
      }
   }

   public function index() {
      $obj = array(
         '_css' => array(
            'assets/plugins/simplepagination/simplePagination.css'
         ),
         '_js' => array(
            'assets/plugins/simplepagination/jquery.simplePagination.js"',
         ),
         'result_view' => 'operator/twitter',
         'user_id' => $this->_user->id
      );
      $this->rendering_page($obj);
   }

   public function get_phone_number(){
      $params = $this->input->get();
      $response['response'] = $this->m_twitter->get_phone_number($params);
      $this->json_result($response);
   }

    public function get_twitter(){
      $param = $this->input->get();
      $list = array();

      $data = $this->m_twitter->get_data_twitter('get',$param);
      if($data){
         foreach ($data as $value) {
            $list[] = array(
               'id' => $value['id'],
               'phone_number' => $value['phone_number'],
               'display_name' => $value['display_name'],
               'screen_name' => $value['screen_name'],
               'email' => $value['email_name'],
               'twitter_id' => $value['twitter_id'],
               'followers' => $value['followers'],
               'status_email' => $value['status_email'],
               'status_phone' => $value['status_phone'],
               'status' => $this->status($value['status']),
               'created_date' => date('d M Y', strtotime($value['created_date'])),
               'pic' => $value['pic'],
            );
         }
         $response['data'] = $list;
         $response['total'] = $this->m_twitter->get_data_twitter('count',$param);
      }else{
         $response['total']=0;
      }

      echo json_encode($response);
   }

   public function status($status){
      switch ($status) {
         case '0':
            return '<span class="label label-default" data-toggle="tooltip" data-original-title="No Action"><i class="fa fa-minus"></i></span>';
            break;
         case '1':
            return '<span class="label label-success" data-toggle="tooltip" data-original-title="Active"><i class="fa fa-check"></i></span>';
            break;
         case '2':
            return '<span class="label label-danger" data-toggle="tooltip" data-original-title="Expired"><i class="fa fa-remove"></i></span>';
            break;
      }
   }

   public function input_twitter(){
      $params = $this->input->post();
      $response['success'] = FALSE;
      $params['user_id'] = $this->_user->id;
      
      if($this->validation_twitter->create($params)){
         $checking = $this->m_twitter->checking($params);
         if($checking){
            $data = $this->m_twitter->input_data($params);
            if($data){
               $response['success'] = TRUE;
               $response['msg'] = 'Data Updated';
            }else{
               $response['msg'] = 'Function Failed';
            }
         }else{
            $response['msg'] = 'Phone Number or Email Not Active';
         }
      }else{
         $response['msg'] = validation_errors();
      }  

      $this->json_result($response);
   }

    public function edit(){
      $params = $this->input->post();
      $response['success'] = FALSE;
      $params['user_id'] = $this->_user->id;

      if($this->validation_twitter->modify_data($params)){   
         $checking = $this->m_twitter->checking($params);
         if($checking){
            $data = $this->m_twitter->update_data($params);
            if($data){
               $response['success'] = TRUE;
               $response['msg'] = 'Data Updated';
            }else{
               $response['msg'] = 'Function Failed';
            }
         }else{
            $response['msg'] = 'Phone Number or Email Not Active';
         } 
      }else{
         $response['msg'] = validation_errors();
      }
      $this->json_result($response);
   }

   public function hapus(){
      $params = $this->input->get();
      $response['success'] = FALSE;
      $data=$this->m_twitter->delete_data($params);
      if($data){
         $response['success'] = TRUE;
         $response['msg'] = 'Data Updated';
      }else{
         $response['msg'] = 'Function Failed';
      }

      $this->json_result($response);
   }

   public function ambil_edit(){
      $params = $this->input->get();
      $response['response'] = $this->db->get_where('twitter', array('id' => $params['id']))->row_array();
      $this->json_result($response);
   }

}

?>