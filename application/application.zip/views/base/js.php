<!-- Bottom scripts (common) -->
<link rel="stylesheet" href="<?php echo base_url() ?>assets/js/vertical-timeline/css/component.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/js/select2/select2-bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/js/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/js/selectboxit/jquery.selectBoxIt.css">


<script src="<?php echo base_url() ?>assets/js/gsap/TweenMax.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/bootstrap.js"></script>
<script src="<?php echo base_url() ?>assets/js/joinable.js"></script>
<script src="<?php echo base_url() ?>assets/js/resizeable.js"></script>
<script src="<?php echo base_url() ?>assets/js/neon-api.js"></script>

<script src="<?php echo base_url() ?>assets/js/select2/select2.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/neon-custom.js"></script>
<script src="<?php echo base_url() ?>assets/js/neon-demo.js"></script>
<script src="<?php echo base_url() ?>assets/js/toastr.js"></script>
<script src="<?php echo base_url() ?>assets/js/moment.min.js"></script>
<script src="<?php echo base_url() ?>assets/setup.js"></script>
<script src="<?php echo base_url() ?>assets/widget.js"></script>

<script src="<?php echo base_url() ?>assets/plugins/daterangepicker/js/daterangepicker.js"></script>
<script src="<?php echo base_url() ?>assets/js/icheck/icheck.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/jquery.form.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/highcharts/js/highcharts.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/plugins/awasomecloud/jquery.tx3-tag-cloud.js" type="text/javascript"></script>
