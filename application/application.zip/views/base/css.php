<link rel="stylesheet" href="<?php echo base_url() ?>assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/font-icons/entypo/css/entypo.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/font-icons/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/neon-core.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/neon-theme.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/neon-forms.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/custom.css">
<link rel="stylesheet" href="<?php echo base_url() ?>ebdesk.css">
<link rel="stylesheet" href="<?php echo base_url() ?>refreshing.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/daterangepicker/css/daterangepicker.css">
<link href="<?php echo base_url() ?>assets/plugins/awasomecloud/tx3-tag-cloud.css" media="screen" rel="stylesheet" type="text/css">
