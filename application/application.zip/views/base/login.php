<!DOCTYPE html>
<html lang="en">
<head>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">

   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <meta name="description" content="Neon Admin Panel" />
   <meta name="author" content="" />

   <link href="<?php echo base_url('favicon.png'); ?>" rel="shortcut icon"/>

   <title>OpsInt | Login</title>

   <link rel="stylesheet" href="<?php echo base_url() ?>assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css">
   <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/font-icons/entypo/css/entypo.css">
   <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic">
   <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.css">
   <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/neon-core.css">
   <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/neon-theme.css">
   <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/neon-forms.css">
   <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/custom.css">
   <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/font-icons/font-awesome/css/font-awesome.min.css">
   <link rel="stylesheet" href="<?php echo base_url() ?>assets/js/vertical-timeline/css/component.css">
   <script src="<?php echo base_url() ?>assets/js/jquery-1.11.3.min.js"></script>
   <style type="text/css">
      hr{
         margin:0px;
      }
      .label{
         font-size: 13px;
      }
   </style>
</head>
<body>
   <div class="col-md-12" style="border:0px solid black;">
      <div class="row">
         <div class="col-md-8" style="padding:20px;">
            <h2 class="text-info"><b>Today</b> Activity</h2><hr>
            <div class="row" style="margin-top: 10px;">
               <div class="col-md-4" style="border-right: 1px solid #e4e4e4;">
                  <h1 class="text-center bold" id="show_number">0</h1>
                  <h4 class="text-center">New Number Card</h4>
               </div>
               <div class="col-md-8" style="margin-top: 10px;" id="name0">

               </div>
            </div>
            <div class="row">
               <div class="col-md-4" style="border-right: 1px solid #e4e4e4;">
                  <h1 class="text-center bold" id="show_email">0</h1>
                  <h4 class="text-center">New Email</h4>
               </div>
               <div class="col-md-8" style="margin-top: 10px;">
                  <h4 class="bold">Pic By</h4>
                  <div class="col-md" style="margin-top: 10px;" id="name1">

                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-4" style="border-right: 1px solid #e4e4e4;">
                  <h1 class="text-center bold" id="show_facebook">0</h1>
                  <h4 class="text-center">New Facebook</h4>
               </div>
               <div class="col-md-8" style="margin-top: 10px;">
                  <h4 class="bold">Pic By</h4>
                  <div class="col-md" style="margin-top: 10px;" id="name2">

                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-4" style="border-right: 1px solid #e4e4e4;">
                  <h1 class="text-center bold" id="show_twitter">0</h1>
                  <h4 class="text-center">New Twitter</h4>
               </div>
               <div class="col-md-8" style="margin-top: 10px;">
                  <h4 class="bold">Pic By</h4>
                  <div class="col-md" style="margin-top: 10px;" id="name3">

                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-4" style="border-right: 1px solid #e4e4e4;">
                  <h1 class="text-center bold" id="show_instagram">0</h1>
                  <h4 class="text-center">New Instagram</h4>
               </div>
               <div class="col-md-8" style="margin-top: 10px;">
                  <h4 class="bold">Pic By</h4>
                  <div class="col-md" style="margin-top: 10px;" id="name4">

                  </div>
               </div>
            </div>
         </div>

         <div class="col-md-4" style="height:662px;padding:60px;border-left:0px solid black;background-color: #303641;color:#fff">
            <div class="col-md-12 text-center">
               <a href="<?php echo site_url() ?>" class="logo">
                  <img src="<?php echo base_url() ?>ebdesk.svg" width="100" alt="" />
               </a>
            </div>
            <div class="col-md-12 text-center" style="margin-top:20px;">
               <h1 style="color:#fff" class="bold">OpsInt</h1>
               <h4 style="color:#fff">Account Management</h4>
            </div>
            <div class="col-md-12" style="margin-top:50px;">
               <form method="post" action="<?php echo site_url('security/verify') ?>">
                  <div class="form-group">
                     <div class="input-group" style="background-color:#ffffff;">
                        <div class="input-group-addon">
                           <i class="entypo-user"></i>
                        </div>
                        <input type="text" class="form-control" name="username" id="username" placeholder="Username" autocomplete="off" />
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="input-group" style="background-color:#ffffff;">
                        <div class="input-group-addon">
                           <i class="entypo-key"></i>
                        </div>
                        <input type="password" class="form-control" name="password" id="password" placeholder="Password" />
                     </div>
                  </div>
                  <div class="form-group">
                     <button type="submit" class="btn btn-primary pull-right">
                        <i class="entypo-login"></i> Login In
                     </button>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>

   <script type="text/javascript">

      $(function(){ 

         $.fn.render_data  = function(params){
            ajaxManager.addReq({
               type : "GET",
               url : "<?php echo base_url('index.php/security/get_count')?>",
               dataType : "JSON",
               data : { },
               success : function(r){
                  var i=0;
                  var a='<h4 class="bold">Pic By</h4>'; 
                  var b=''; 
                  var c=''; 
                  var d=''; 
                  var e=''; 
                  
                  $.each(r.data.data.simcards, function(key,value){
                     a+='<span class="label label-primary" >'+value.name+' : '+value.subtot+'</span>';
                     i++;
                     if(i%6==0){
                        a+='<br><br>';
                     }
                  });
                  $.each(r.data.data.emails, function(key,value){
                     b+='<span class="label label-primary" >'+value.name+' : '+value.subtot+'</span>';
                  });
                  $.each(r.data.data.facebooks, function(key,value){
                     c+='<span class="label label-primary" >'+value.name+' : '+value.subtot+'</span>';
                  });
                  $.each(r.data.data.twitters, function(key,value){
                     d+='<span class="label label-primary" >'+value.name+' : '+value.subtot+'</span>';
                  });
                  $.each(r.data.data.instagrams, function(key,value){
                     e+='<span class="label label-primary" >'+value.name+' : '+value.subtot+'</span>';
                  });

                  $('#name0').html(a);
                  $('#name1').html(b);
                  $('#name2').html(c);
                  $('#name3').html(d);
                  $('#name4').html(e);
                  
                  $('#show_number').html(r.data.total.simcards.totals);
                  $('#show_email').html(r.data.total.emails.totals);
                  $('#show_facebook').html(r.data.total.facebooks.totals);
                  $('#show_twitter').html(r.data.total.twitters.totals);
                  $('#show_instagram').html(r.data.total.instagrams.totals);
               }
            });
         };

      $(this).render_data();
   });

   </script>
   
   <script src="<?php echo base_url() ?>assets/js/gsap/TweenMax.min.js"></script>
   <script src="<?php echo base_url() ?>assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js"></script>
   <script src="<?php echo base_url() ?>assets/js/bootstrap.js"></script>
   <script src="<?php echo base_url() ?>assets/js/joinable.js"></script>
   <script src="<?php echo base_url() ?>assets/js/resizeable.js"></script>
   <script src="<?php echo base_url() ?>assets/js/neon-api.js"></script>
   <script src="<?php echo base_url() ?>assets/js/jquery.validate.min.js"></script>
   <script src="<?php echo base_url() ?>assets/js/neon-login.js"></script>
   <script src="<?php echo base_url('assets/js/jquery.form.js') ?>"></script>
   <script src="<?php echo base_url() ?>assets/js/neon-custom.js"></script>
   <script src="<?php echo base_url() ?>assets/js/neon-demo.js"></script>
   <script src="<?php echo base_url() ?>assets/setup.js"></script>

    

</body>
</html>