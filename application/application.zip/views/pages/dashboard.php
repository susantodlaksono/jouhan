<div class="row">
   <div class="col-md-2">
      <div class="panel panel-primary" data-collapsed="0">
         <div class="panel-heading">
            <div class="panel-title"><i class="fa fa-list"></i> All Summary</div>
         </div>
         <div class="panel-body" id="widget-all-summary" style="padding:2px;">
      	</div>
      </div>
   </div>
</div>

<script type="text/javascript">
   var sessions = '#<?php echo $this->ion_auth->logged_in() ?>';
	var loading = '<i class="fa fa-spinner fa-spin"></i>';
	var overlay = '<h3 class="text-center text-danger overlay"><i class="fa fa-spinner fa-spin"></i></h3>';

   $(function(){ 
   	Widget.Loader('all_summary', {
   		sdate: null,
   		edate: null,
   	}, 
   	'widget-all-summary');
	});

</script>